package com.example.test10

data class VoteData (
    var title: String,
    var explain: String,
    var starttime: String,
    var endtime: String
)