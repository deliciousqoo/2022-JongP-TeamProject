package com.example.test10

data class VoteContents(var title: String, var writer: String, var status: String)
