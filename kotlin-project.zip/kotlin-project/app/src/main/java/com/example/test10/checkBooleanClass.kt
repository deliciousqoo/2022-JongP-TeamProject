package com.example.test10

data class checkBooleanClass (
    val checkBoolean : Boolean
)