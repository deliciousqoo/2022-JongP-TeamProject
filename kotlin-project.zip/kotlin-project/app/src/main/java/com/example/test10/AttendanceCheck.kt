package com.example.test10

data class AttendanceCheck(var name: String, var rank: String, var attendance: Boolean)